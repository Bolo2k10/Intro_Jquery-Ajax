# Twitter-Bot
This is a Twitter Bot that will follow all users that follow the given Twitter account, and display a GUI application

![](GUI.png)

In the application you can search keywords on twitter and choose to respond to, favorite, retweet the tweet and/or follow the user that tweeted. Along with selecting how many tweets you would like to interact with. 

[Here is a step by step tutorial on how I coded this.](https://medium.com/@Fidel_Willis/creating-a-twitter-bot-in-python-with-tweepy-ac524157a607)
